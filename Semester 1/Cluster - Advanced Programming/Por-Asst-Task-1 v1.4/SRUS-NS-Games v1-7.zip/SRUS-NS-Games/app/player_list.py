# app/player_list.py

"""Notes:

__init__ is the constructor method that initializes a new instance
of the PlayerList class with head and tail pointers set to None.

head and tail properties are used to access the head and tail nodes of the list.

is_empty method checks if the list is empty by verifying if the head pointer is None.

"""

class PlayerList:
    def __init__(self):
        """
        Initialize an empty player list with a head pointer.
        """
        self._head = None  # Head of the linked list
        self._tail = None  # Tail of the linked list

def is_empty(self):
    """
    Checks if the list is empty.
    :param self:
    :return: true if the list is empty, false otherwise
    """
    return self._head is None

def insert_at_head(self, player):
    """
    Inserts the player at the head of the list.
    :param self:
    :param player: player object to be added to the list.
    :return:
    """
    new_node = PlayerNode(player) # creating a new PlayerNode
    if self.is_empty():
        # if the list is empty the new node is both head and tail
        self._head = new_node
        self._tail = new_node
    else:
        # if the list is not empty update the pointers
        new_node.next = self._head
        self._head.prev = new_node
        self._head = new_node

def insert_at_tail(self, player):
    """
    Inserts the player at the tail of the list.
    :param self:
    :param player: player object to be added to the list.
    :return:
    """
    new_node = PlayerNode(player)
    if self.is_empty():
        self._head = new_node
        self._tail = new_node
    else:
        new_node.prev = self._tail
        self._tail.next = new_node
        self._tail = new_node
"""
The is_empty method checks if the list is empty by verifying if the head pointer is None.
The insert_at_head method checks if the head pointer is empty and adds a new node to the list.

Both 'head' and 'tail' point to a new node otherwise the new node is added to the front of the current head 
and pointers are updated.
"""

    @property
    def head(self):
        """
        Get the head node of the list.
        Returns:
            PlayerNode: The head node of the list.
        """
        return self._head

    @property
    def tail(self):
        """
        Get the tail node of the list.
        Returns:
            PlayerNode: The tail node of the list.
        """
        return self._tail

    def is_empty(self):
        """
        Check if the list is empty.
        Returns:
            bool: True if the list is empty, False otherwise.
        """
        return self._head is None  # Return True if head is None
